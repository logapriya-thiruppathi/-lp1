// Example JS (not required heavily in this project)
console.log("Responsive gallery loaded.");
